# TODO: Remove this file when  v15.0.0 is released
from setuptools import setup

name = "shoperprime"

setup()
